<h2 align="left">I'm Nodejs mongodb developer and more...</h2>

<img align="right" height="150" src="https://camo.githubusercontent.com/1f6b092f216bb3d020104e58371cdb4ce2529983ead4ad51aa23bd459b201a06/68747470733a2f2f692e70696e696d672e636f6d2f6f726967696e616c732f66332f62382f36332f66336238363333656633366266306235303835633564306636303230633931392e676966"  />
<div align="center">
  <img src="https://github-readme-stats.vercel.app/api/top-langs?username=Tunar-Hasanov&locale=en&hide_title=false&layout=compact&card_width=320&langs_count=5&theme=dracula&hide_border=false&order=2" height="150" alt="languages graph"  />
</div>

###

###

###

<div align="left">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" height="40" alt="javascript logo" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/typescript/typescript-original.svg" height="40" alt="typescript logo" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original.svg" height="40" alt="nodejs logo" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/socketio/socketio-original.svg" height="40" alt="Socketio logo" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mongodb/mongodb-original.svg" height="40" alt="Mongodb logo" />
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original-wordmark.svg" height="40" alt="Html5" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg" height="40" alt="mysql logo" />
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/nginx/nginx-original.svg" height="40" alt="ngnix logo" />
  <img src="https://www.svgrepo.com/show/303229/microsoft-sql-server-logo.svg" height="40" alt="sql logo" />
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/docker/docker-original-wordmark.svg" height="40" alt="docker logo" />
  <img src="https://www.vectorlogo.zone/logos/git-scm/git-scm-icon.svg" height="40" alt="git logo" />
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/linux/linux-original.svg" height="40" alt="linux logo" />
  <img src="https://www.vectorlogo.zone/logos/apache/apache-ar21.svg" height="" alt="Apache logo" />
</div>


###

<div align="left">
 <a href="https://www.instagram.com/metlebqlyv/" target="_blank">
  <img src="https://img.shields.io/static/v1?message=Instagram&logo=instagram&label=&color=E4405F&logoColor=white&labelColor=&style=for-the-badge" height="35" alt="Instagram Logo">
</a>

<a href="https://discord.com/channels/error" target="_blank">
  <img src="https://img.shields.io/static/v1?message=Discord&logo=discord&label=&color=5865F2&logoColor=white&labelColor=&style=for-the-badge" height="35" alt="Discord Logo">
</a>
<a href="mailto:metlebquliyev9@gmail.com" target="_blank">
  <img src="https://img.shields.io/static/v1?message=Gmail&logo=gmail&label=&color=D14836&logoColor=white&labelColor=&style=for-the-badge" height="35" alt="Gmail Logo">
</a>
<a href="https://api.whatsapp.com/send/?phone=99450&text&type=phone_number&app_absent=0" target="_blank">
</a>

</div>

###

<br clear="both">

<img src="https://raw.githubusercontent.com/platane/snk/output/github-contribution-grid-snake.svg" />

###
